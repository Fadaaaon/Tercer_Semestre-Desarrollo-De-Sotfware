import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  public title1 : string = "Tercer Semestre";
  public title2 : string = "Mi Primera Clase";
  public title3 : string = "Contador 1"
  public title4 : string = "Contador 2"
  public counter : number = 10;
  public counter2 : number = 5;

  increaseBy () :void {
    this.counter+= 1;
  }
  decreaseBy () :void{
    this.counter-= 1;
  }

  modificar_numero (value : number) :void{
    this.counter2 += value;
  }
  resetcounter () : void{
    this.counter =10;
    this.counter2 =5;
  }
}
