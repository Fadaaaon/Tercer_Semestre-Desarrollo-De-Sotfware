import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'

})
export class AppComponent {
  title = 'MiniCalculadora';
  numero1: number = 0;
  numero2: number = 0;
  resultado: number = 0;

  updateNumero1(event: any) {
    this.numero1 = parseInt(event.target.value);
  }

  updateNumero2(event: any) {
    this.numero2 = parseInt(event.target.value);
  }

  sumar() {
    this.resultado = this.numero1 + this.numero2;
  }

  restar() {
    this.resultado = this.numero1 - this.numero2;
  }
}
